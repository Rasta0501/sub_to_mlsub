# 普通订阅转免流订阅 
- 原理  
  - 将原来的订阅解析后添加免流host
  - 使用方法   服务器域名/&&订阅链接&&免流host&&转换后服务器前缀
  - 我这里已经在服务器上搭建好了    http://jklist.ml:888
  - 实例链接  http://jklist.ml:888/&&https://sub.qaq.wtf/&&m.iqiyi.com&&iqiyi  
  - 解释  jklist.ml:888/  为服务器域名
  - https://sub.qaq.wtf/ 为订阅链接
  - m.iqiyi.com为免流host 
  - iqiyi 为转换后手机上显示的服务器名称前缀可为空则不修(如软件支持中文可使用中文)
- 更新记录
  - 20210222 更新   鉴于有些订阅里面包含有一个&符号  导致不可用  现更改为两个&&符号来进行分割
  - 20210304 更新   端口筛选+后端http多线程处理 从订阅池或者机场的订阅里面筛选 、 多线程避免因某订阅链接响应过慢导致整个程序等待超时响应 
#
- 白嫖链接
  - https://sspool.herokuapp.com/vmess/sub   订阅池 什么都有
  - https://proxy.moneyfly.club/vmess/sub    订阅池 什么都有


- 推荐免流机场  80+ws模式
  - http://免流骚.com   
# 欢迎加入讨论群:<https://t.me/mlsao>


